package ws.fruitbowl.grader;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.LinkedList;

public class Student {
    private int studentID;
    private String name;

    private LinkedList<File> homeworkFiles;

    public Student(int studentID, String name) {
        this.studentID = studentID;
        this.name = name.replace(' ', '_');
        homeworkFiles = new LinkedList<>();
    }

    public void addHomework(File homeworkfile){
        homeworkFiles.add(homeworkfile);
    }

    public void composeHomeworkFiles(){

        File folder = new File(homeworkFiles.getFirst().getParentFile().toString() + "/" + studentID + '-' + name);
        folder.mkdir();
        for(File f: homeworkFiles) {
            Path target = Paths.get(folder.toString() + "/" + f.getName().substring(f.getName().lastIndexOf('-') + 2));
            try {
                Files.move(f.toPath(), target, StandardCopyOption.REPLACE_EXISTING);
            }catch (IOException ioe){
                ioe.printStackTrace();
            }
        }
    }

    public int getStudentID(){
        return studentID;
    }

    @Override
    public boolean equals(Object obj) {
        Student s = (Student) obj;
        if(s != null){
            return (s.studentID == this.studentID);
        }
        return false;
    }
}
